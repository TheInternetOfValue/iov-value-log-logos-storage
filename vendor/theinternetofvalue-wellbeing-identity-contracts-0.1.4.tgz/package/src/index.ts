export type CanonicalMemberDid = `did:iov:member:${string}` & { readonly __brand: "CanonicalMemberDid" };

const DID = /^did:iov:member:[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;

export function parseCanonicalMemberDid(value: string): CanonicalMemberDid {
  if (!DID.test(value)) throw new Error("INVALID_CANONICAL_MEMBER_DID");
  return value as CanonicalMemberDid;
}

export const WELLBEING_IDENTITY_NODES = [
  "~~GivenIdentity", "~~EarnedIdentity", "~~RentedIdentity", "~~Skills",
  "~~MoralCompass", "~~Story", "~~IdentityState", "~~ConsentAndDisclosure",
] as const;
export type WellbeingIdentityNode = typeof WELLBEING_IDENTITY_NODES[number];

/**
 * The semantic visual order for the shared eight-ring portrait. This is not a
 * change to protocol-node authority or storage order: it is the stable visual
 * grammar used by every renderer consumer.
 */
export const WELLBEING_IDENTITY_EIGHT_RING_PROFILE = [
  { path: "~~GivenIdentity", label: "Given identity", color: "#E53935", order: 0 },
  { path: "~~EarnedIdentity", label: "Earned identity", color: "#FB8C00", order: 1 },
  { path: "~~RentedIdentity", label: "Rented identity", color: "#FDD835", order: 2 },
  { path: "~~MoralCompass", label: "Moral compass", color: "#43A047", order: 3 },
  { path: "~~Story", label: "Story", color: "#1E88E5", order: 4 },
  { path: "~~Skills", label: "Skills", color: "#3949AB", order: 5 },
  { path: "~~IdentityState", label: "Identity state", color: "#8E24AA", order: 6 },
  { path: "~~ConsentAndDisclosure", label: "Consent and disclosure", color: "#F8FAFC", order: 7 },
] as const satisfies ReadonlyArray<{ path: WellbeingIdentityNode; label: string; color: `#${string}`; order: number }>;

export type WellbeingIdentityVisualNode = typeof WELLBEING_IDENTITY_EIGHT_RING_PROFILE[number];

/**
 * A JSON-safe value returned by an owner-authorised facet projection. Keeping
 * records and lists typed here prevents consumers from pretending a recorded
 * history is a string (and rendering it as "[object Object]").
 */
export type WellbeingIdentityFacetValue =
  | string
  | number
  | boolean
  | null
  | ReadonlyArray<WellbeingIdentityFacetValue>
  | { readonly [field: string]: WellbeingIdentityFacetValue };

export function wellbeingIdentityVisualNode(path: WellbeingIdentityNode): WellbeingIdentityVisualNode {
  const node = WELLBEING_IDENTITY_EIGHT_RING_PROFILE.find((candidate) => candidate.path === path);
  if (!node) throw new Error("UNKNOWN_WELLBEING_IDENTITY_VISUAL_NODE");
  return node;
}

type ProjectionBase = {
  identityDid: CanonicalMemberDid;
  protocolVersion: string;
  projectionSchemaVersion: "wellbeing-identity-projection-v1";
  disclosureVersion: string;
};

export type PublicWellbeingIdentityProjection = ProjectionBase & {
  purpose: "public-profile"; audience: "public"; disclosedAt: string;
  displayName: string; nodes: ReadonlyArray<{ path: WellbeingIdentityNode; label: string; summary: string }>;
};

export type ReplayIdentityProjection = ProjectionBase & {
  purpose: "owner-authorised-replay"; audience: "identity-owner"; expiresAt?: string;
  displayName: string; nodes: ReadonlyArray<{ path: WellbeingIdentityNode; label: string; visible: boolean }>;
};

/**
 * The complete projection that an identity owner has authorised for a private
 * product surface. It deliberately contains identity-domain information only:
 * Value Log activities, W transitions, evidence and Performance routes are
 * never part of this contract.
 */
export type OwnerWellbeingIdentityProjection = ProjectionBase & {
  purpose: "owner-private-profile"; audience: "identity-owner";
  displayName: string; profileVersion: string; provenanceVersion: string;
  nodes: ReadonlyArray<{
    path: WellbeingIdentityNode; label: string; visible: boolean;
    facets: ReadonlyArray<{
      path: string; label: string; value: WellbeingIdentityFacetValue;
      disclosure: "private" | "public" | "selective" | "withheld";
      provenance?: string;
    }>;
  }>;
};

export type ExplorerIdentityProjection = ProjectionBase & {
  purpose: "guided-protocol-example"; audience: "demo";
  displayName: string; nodes: ReadonlyArray<{ path: WellbeingIdentityNode; label: string; visible: boolean }>;
};

export type IdentityStateReplayInput = {
  identityDid: CanonicalMemberDid; canonicalSliceId: string; settledAt: string;
  prePilotW: number; appliedPilotW: number; postPilotW: number;
  node: "~~IdentityState"; calculatorVersion: string; reversed: false;
  performanceRoute?: { destination: string; credits: number };
};
