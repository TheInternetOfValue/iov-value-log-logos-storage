import assert from "node:assert/strict";
import test from "node:test";
import { parseCanonicalMemberDid, WELLBEING_IDENTITY_EIGHT_RING_PROFILE, WELLBEING_IDENTITY_NODES } from "./index.js";

test("canonical member DIDs require the UUID method form", () => {
  assert.equal(parseCanonicalMemberDid("did:iov:member:b6535d69-208f-4e57-af11-ceccdebab7e1"), "did:iov:member:b6535d69-208f-4e57-af11-ceccdebab7e1");
  assert.throws(() => parseCanonicalMemberDid("did:iov:member:moses-sam-paul"));
});
test("renderer contract preserves the canonical eight-node order", () => {
  assert.deepEqual(WELLBEING_IDENTITY_NODES.slice(-2), ["~~IdentityState", "~~ConsentAndDisclosure"]);
  assert.equal(WELLBEING_IDENTITY_NODES.length, 8);
});

test("the eight-ring visual profile keeps Given Identity innermost and Identity State seventh", () => {
  assert.deepEqual(WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => node.path), [
    "~~GivenIdentity", "~~EarnedIdentity", "~~RentedIdentity", "~~MoralCompass",
    "~~Story", "~~Skills", "~~IdentityState", "~~ConsentAndDisclosure",
  ]);
  assert.deepEqual(WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => node.color), [
    "#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#3949AB", "#8E24AA", "#F8FAFC",
  ]);
});
