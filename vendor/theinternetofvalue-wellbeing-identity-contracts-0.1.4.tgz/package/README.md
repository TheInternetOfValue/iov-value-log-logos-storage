# Wellbeing Identity contracts

`@theinternetofvalue/wellbeing-identity-contracts` defines versioned,
data-minimized Wellbeing Identity projections. It owns no profile data and does
not authorise reads or writes. Version `0.1.0` supports protocol `0.6.0` and
projection schema `wellbeing-identity-projection-v1`.
