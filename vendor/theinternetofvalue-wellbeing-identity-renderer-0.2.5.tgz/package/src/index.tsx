import type { ExplorerIdentityProjection, OwnerWellbeingIdentityProjection, PublicWellbeingIdentityProjection, ReplayIdentityProjection, WellbeingIdentityNode } from "@theinternetofvalue/wellbeing-identity-contracts";
import { WELLBEING_IDENTITY_EIGHT_RING_PROFILE, wellbeingIdentityVisualNode } from "@theinternetofvalue/wellbeing-identity-contracts";
import React from "react";

export type RendererProfile = "explorer" | "replay" | "public";
export type RendererTransition = { appliedPilotW: number; postPilotW: number; canonicalSliceId: string };
type Projection = ReplayIdentityProjection | OwnerWellbeingIdentityProjection | PublicWellbeingIdentityProjection | ExplorerIdentityProjection;

const AURA_POINT_POSITIONS: Record<WellbeingIdentityNode, { top: string; illumination?: boolean }> = {
  "~~GivenIdentity": { top: "75%" },
  "~~EarnedIdentity": { top: "64%" },
  "~~RentedIdentity": { top: "53%" },
  "~~MoralCompass": { top: "42%" },
  "~~Story": { top: "29%" },
  "~~Skills": { top: "16%" },
  "~~IdentityState": { top: "2%" },
  "~~ConsentAndDisclosure": { top: "-10%", illumination: true },
};

function displayColor(node: { path: WellbeingIdentityNode; color: string }) {
  return node.path === "~~ConsentAndDisclosure" ? "#676B74" : node.color;
}

/** Shared, disclosure-neutral eight-ring scene. It never fetches or writes. */
export function WellbeingIdentityRenderer({ projection, profile, transition, activeNode, previewNode, interactiveNodes, nodeAnnotations, onNodeSelect, onNodePreview, onNodePreviewEnd, reducedMotion = false }: {
  projection: Projection; profile: RendererProfile; transition?: RendererTransition; activeNode?: WellbeingIdentityNode; previewNode?: WellbeingIdentityNode | null;
  interactiveNodes?: readonly WellbeingIdentityNode[];
  nodeAnnotations?: Partial<Record<WellbeingIdentityNode, readonly string[]>>;
  onNodeSelect?: (node: WellbeingIdentityNode) => void; onNodePreview?: (node: WellbeingIdentityNode) => void; onNodePreviewEnd?: () => void; reducedMotion?: boolean;
}) {
  assertCompatibleProjection(projection, profile);
  const interactive = Boolean(onNodeSelect || onNodePreview);
  const selectablePaths = interactiveNodes?.length
    ? WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => node.path).filter((path) => interactiveNodes.includes(path))
    : WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => node.path);
  const fallbackPath = profile === "replay" ? "~~IdentityState" : "~~GivenIdentity";
  const selectedPath = activeNode && (!interactive || selectablePaths.includes(activeNode)) ? activeNode : selectablePaths[0] ?? fallbackPath;
  const scenePath = previewNode && selectablePaths.includes(previewNode) ? previewNode : selectedPath;
  const sceneVisual = wellbeingIdentityVisualNode(scenePath);
  const sceneColor = displayColor(sceneVisual);
  const renderedNodes = WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((visual) => {
    const projectionNode = projection.nodes.find((node) => node.path === visual.path);
    if (!projectionNode) throw new Error("MISSING_WELLBEING_IDENTITY_RENDERER_NODE");
    return { ...visual, label: projectionNode.label };
  });
  const keyDown = (event: React.KeyboardEvent<SVGGElement>, path: WellbeingIdentityNode) => {
    const index = selectablePaths.indexOf(path);
    if (["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key)) {
      event.preventDefault(); const delta = event.key === "ArrowRight" || event.key === "ArrowDown" ? 1 : -1;
      const next = selectablePaths[(index + delta + selectablePaths.length) % selectablePaths.length];
      if (!next) return;
      onNodePreview?.(next); event.currentTarget.ownerSVGElement?.querySelector<SVGGElement>(`[data-iov-node="${next}"]`)?.focus(); return;
    }
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); onNodeSelect?.(path); }
  };
  return <figure className={`iov-identity-renderer iov-identity-renderer--${profile}${transition && scenePath === "~~IdentityState" ? " is-transitioning" : ""}${interactive ? " is-interactive" : ""}${previewNode ? " is-previewing" : ""}${reducedMotion ? " is-reduced-motion" : ""}`} style={{ "--iov-active": sceneColor, "--iov-active-order": sceneVisual.order } as React.CSSProperties} aria-label={`Eight-ring Wellbeing Identity portrait for ${projection.displayName}; ${previewNode ? "previewing" : "selected"} node: ${sceneVisual.label}`} onPointerLeave={interactive ? onNodePreviewEnd : undefined}>
    <svg className="iov-identity-rings" viewBox="0 0 440 440" role={interactive ? "group" : "img"} aria-label={`${sceneVisual.label} ${previewNode ? "previewed" : "selected"}`}>
      <defs><radialGradient id="iov-identity-aura" cx="50%" cy="50%" r="50%"><stop offset="0" stopColor="#f7f3ec" stopOpacity=".72" /><stop offset=".42" stopColor={sceneColor} stopOpacity=".32" /><stop offset="1" stopColor="#11151e" stopOpacity="0" /></radialGradient></defs><circle className="iov-identity-weather" cx="220" cy="220" r="162" fill="url(#iov-identity-aura)" />
      {renderedNodes.map((node) => { const radius = 66 + node.order * 18; const active = node.path === scenePath; const selected = node.path === selectedPath; const enabled = interactive && selectablePaths.includes(node.path); return <g key={node.path} className={`${active ? "is-current" : ""}${interactive && !enabled ? " is-disabled" : ""}`.trim() || undefined} data-iov-node={node.path} role={enabled ? "button" : undefined} tabIndex={enabled ? 0 : undefined} aria-label={enabled ? `Explore ${node.label}; press Enter to select` : undefined} aria-pressed={enabled ? selected : undefined} aria-disabled={interactive && !enabled ? true : undefined} onClick={enabled ? () => onNodeSelect?.(node.path) : undefined} onPointerEnter={enabled ? () => onNodePreview?.(node.path) : undefined} onFocus={enabled ? () => onNodePreview?.(node.path) : undefined} onKeyDown={enabled ? (event) => keyDown(event, node.path) : undefined}><circle className="iov-identity-ring" cx="220" cy="220" r={radius} fill="none" stroke={displayColor(node)} />{enabled ? <circle className="iov-identity-ring-hit" cx="220" cy="220" r={radius} fill="none" stroke="transparent" /> : null}</g>; })}
    </svg>
    <div className="iov-identity-person" aria-hidden="true"><span className="iov-identity-person-glow" /><span className="iov-identity-spine" />{renderedNodes.map((node) => { const position = AURA_POINT_POSITIONS[node.path]; return <span className={`iov-identity-point${node.path === scenePath ? " is-current" : ""}${position.illumination ? " is-illumination" : ""}`} key={node.path} style={{ "--iov-point-top": position.top, "--iov-point-color": displayColor(node) } as React.CSSProperties} />; })}<b className="iov-identity-head" /><i className="iov-identity-body" /><em className="iov-identity-arm is-left" /><em className="iov-identity-arm is-right" /><em className="iov-identity-leg is-left" /><em className="iov-identity-leg is-right" /></div>
    {transition && scenePath === "~~IdentityState" ? <span className="iov-identity-ember-arrival" aria-hidden="true" /> : null}<figcaption className="iov-identity-caption">{previewNode ? `Preview · ${sceneVisual.label}` : sceneVisual.label}</figcaption>
    {nodeAnnotations?.[scenePath]?.length ? <div className="iov-identity-annotations" aria-live="polite"><strong>{sceneVisual.label}</strong><span>{nodeAnnotations[scenePath]!.slice(0, 3).join(" · ")}</span>{nodeAnnotations[scenePath]!.length > 3 ? <small>+{nodeAnnotations[scenePath]!.length - 3} more</small> : null}</div> : null}
  </figure>;
}
function assertCompatibleProjection(projection: Projection, profile: RendererProfile) { if (projection.projectionSchemaVersion !== "wellbeing-identity-projection-v1") throw new Error("UNSUPPORTED_WELLBEING_IDENTITY_PROJECTION_SCHEMA"); if (profile === "public" && projection.audience !== "public") throw new Error("INCOMPATIBLE_RENDERER_PROFILE"); if (profile === "replay" && projection.audience !== "identity-owner") throw new Error("INCOMPATIBLE_RENDERER_PROFILE"); if (profile === "explorer" && projection.audience !== "demo") throw new Error("INCOMPATIBLE_RENDERER_PROFILE"); }
