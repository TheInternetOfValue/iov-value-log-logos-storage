import type { WellbeingIdentityNode } from "@theinternetofvalue/wellbeing-identity-contracts";
import { WELLBEING_IDENTITY_EIGHT_RING_PROFILE, wellbeingIdentityVisualNode } from "@theinternetofvalue/wellbeing-identity-contracts";

/** Framework-neutral interactive SVG markup for the public Vue surface. */
export function wellbeingIdentitySvg(activeNode: WellbeingIdentityNode = "~~GivenIdentity"): string {
  const active = wellbeingIdentityVisualNode(activeNode);
  const displayColor = (node: { path: WellbeingIdentityNode; color: string }) => node.path === "~~ConsentAndDisclosure" ? "#676B74" : node.color;
  const pointY: Record<WellbeingIdentityNode, number> = { "~~GivenIdentity": 330, "~~EarnedIdentity": 282, "~~RentedIdentity": 238, "~~MoralCompass": 194, "~~Story": 142, "~~Skills": 104, "~~IdentityState": 62, "~~ConsentAndDisclosure": 26 };
  const rings = WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => {
    const radius = 66 + node.order * 18;
    const selected = node.path === activeNode;
    return `<g data-iov-node="${node.path}" role="button" tabindex="0" aria-label="Preview ${node.label}; press Enter to select" aria-pressed="${selected}"><circle cx="220" cy="220" r="${radius}" fill="none" stroke="${displayColor(node)}" stroke-opacity="${selected ? ".96" : ".24"}" stroke-width="${selected ? "3" : "1.15"}"/><circle data-iov-hit="true" cx="220" cy="220" r="${radius}" fill="none" stroke="transparent" stroke-width="14" pointer-events="stroke"/></g>`;
  }).join("");
  const points = WELLBEING_IDENTITY_EIGHT_RING_PROFILE.map((node) => `<circle cx="220" cy="${pointY[node.path]}" r="${node.path === activeNode ? "7" : node.path === "~~ConsentAndDisclosure" ? "5" : "4"}" fill="${node.path === activeNode ? displayColor(node) : node.path === "~~ConsentAndDisclosure" ? "#f7f3ec" : "rgba(255,255,255,.16)"}" opacity="${node.path === activeNode ? ".96" : ".35"}"/>`).join("");
  return `<svg viewBox="0 0 440 440" role="group" aria-label="Eight-layer Wellbeing Identity portrait; ${active.label} selected" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="iov-aura" cx="50%" cy="50%" r="50%"><stop stop-color="#f7f3ec" stop-opacity=".72"/><stop offset=".42" stop-color="${displayColor(active)}" stop-opacity=".32"/><stop offset="1" stop-color="#11151e" stop-opacity="0"/></radialGradient></defs><rect width="440" height="440" fill="#11151e"/><circle cx="220" cy="220" r="162" fill="url(#iov-aura)"/>${rings}<g fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="220" cy="130" r="19" stroke="#f7f3ec" stroke-width="5"/><path d="M220 151V296 M220 170c-31 25-32 70 0 113 32-43 31-88 0-113ZM178 252c17-16 28-20 42-20s25 4 42 20M167 300c18-28 35-39 53-39s35 11 53 39" stroke="${displayColor(active)}" stroke-width="5"/></g><path d="M220 160V287" stroke="${displayColor(active)}" stroke-width="3"/>${points}</svg>`;
}
