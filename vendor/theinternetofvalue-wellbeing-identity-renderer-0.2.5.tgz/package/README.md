# Wellbeing Identity renderer

`@theinternetofvalue/wellbeing-identity-renderer` renders disclosure-safe
eight-layer geometry and an abstract central person-form only. It never
fetches, stores, calculates, infers, or exposes undisclosed identity data.

## Compatibility

| Renderer | Contracts | Projection schema |
| --- | --- | --- |
| `0.1.4` | `0.1.1` | `wellbeing-identity-projection-v1` |

Import the package stylesheet once in each renderer consumer:

```ts
import "@theinternetofvalue/wellbeing-identity-renderer/styles.css";
```

`explorer`, `replay`, and `public` are constrained rendering profiles. They
validate projection audience at runtime and reject unsupported projection
schema versions rather than guessing how to render them.

Consumers may provide an `activeNode` that exists in the supplied projection;
the renderer uses it only as a visual focus and never derives identity state.

## Install and release operations

Private-package authentication and the tag-triggered release path are defined
in the canonical [GitHub Packages runbook](../../docs/operational/GITHUB_PACKAGES.md).
Do not add a literal token to a consumer .npmrc or publish a renderer version
directly from a laptop.
